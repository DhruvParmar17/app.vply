let entries = JSON.parse(localStorage.getItem("entries")) || [];

function saveData() {
  localStorage.setItem("entries", JSON.stringify(entries));
  displayEntries(entries);
}

function addEntry() {
  const company = document.getElementById("company").value;
  const phone = document.getElementById("phone").value;
  const godown = document.getElementById("godown").value;
  const owner = document.getElementById("owner").value;
  const gst = document.getElementById("gst").value;
  const products = document.getElementById("products").value;
  const price = document.getElementById("price").value;

  if (company.trim() === "") return;

  entries.push({ company, phone, godown, owner, gst, products, price });
  saveData();
  clearForm();
}

function clearForm() {
  document.querySelectorAll("input").forEach(input => input.value = "");
}

function displayEntries(list) {
  const container = document.getElementById("entries");
  container.innerHTML = "";
  list.forEach((e, i) => {
    container.innerHTML += `
      <div class="entry">
        <strong>${e.company}</strong><br>
        📞 ${e.phone}<br>
        🏠 ${e.godown}<br>
        👤 ${e.owner}<br>
        🧾 ${e.gst}<br>
        📦 ${e.products}<br>
        💰 ${e.price}<br>
        <button onclick="deleteEntry(${i})">Delete</button>
      </div>
    `;
  });
}

function deleteEntry(index) {
  entries.splice(index, 1);
  saveData();
}

function searchEntries() {
  const query = document.getElementById("search").value.toLowerCase();
  const filtered = entries.filter(e =>
    Object.values(e).some(val => val.toLowerCase().includes(query))
  );
  displayEntries(filtered);
}

displayEntries(entries);
